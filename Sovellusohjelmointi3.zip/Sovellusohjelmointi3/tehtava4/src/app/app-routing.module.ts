import { NgModule } from '@angular/core';
import { PreloadAllModules, RouterModule, Routes } from '@angular/router';

const routes: Routes = [
  { path: '', redirectTo: 'home', pathMatch: 'full' },
  { path: 'home', loadChildren: () => import('./home/home.module').then( m => m.HomePageModule)},
  { path: 'tiedot', loadChildren: './tiedot/tiedot.module#TiedotPageModule' },
  { path: 'yhteenveto', loadChildren: './yhteenveto/yhteenveto.module#YhteenvetoPageModule' },
  { path: 'kiitos', loadChildren: './kiitos/kiitos.module#KiitosPageModule' },
];

@NgModule({
  imports: [
    RouterModule.forRoot(routes, { preloadingStrategy: PreloadAllModules })
  ],
  exports: [RouterModule]
})
export class AppRoutingModule { }
