import { Component } from '@angular/core';
import { DataService } from '../data.service';


@Component({
  selector: 'app-home',
  templateUrl: 'home.page.html',
  styleUrls: ['home.page.scss'],
})
export class HomePage {

constructor(private data : DataService) { }

mokit : any[] = [
  {nimi : "Perusmökki", hinta : 80}, 
  {nimi : "Erämökki", hinta : 10},
  {nimi : "Rantamökki", hinta : 150},
  {nimi : "Huvila", hinta : 300}
];
//Tee interface
valinta : number;
mokkiHinta : number;
pvm : string;
pituus : number = 1;
siivous : boolean = false;
siivouskulu : number = 0;
summa : number = 0;
testi : any;

siivousF = () : void => {

if(this.siivous == true) {
  this.summa = 0;
} else {
  this.siivouskulu = 100;
  this.summa = this.siivouskulu;
}
}
muunnos = () : void => {

let uusiData : any = {
  'mokki' : this.valinta,
  'pituus' : this.pituus,
  'yhteensa' : this.valinta * this.pituus + this.siivouskulu,
  'siivous' : this.siivous,
  'pvm' : this.pvm
}

this.data.datat.push(uusiData);

}
}
