import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-kiitos',
  templateUrl: './kiitos.page.html',
  styleUrls: ['./kiitos.page.scss'],
})
export class KiitosPage implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
