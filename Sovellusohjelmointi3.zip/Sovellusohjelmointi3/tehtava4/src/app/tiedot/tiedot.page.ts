import { DataService } from './../data.service';
import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-tiedot',
  templateUrl: './tiedot.page.html',
  styleUrls: ['./tiedot.page.scss'],
})
export class TiedotPage implements OnInit {

  constructor(private data : DataService) { }

nimi : string;
puh : number;
sposti : string
maksu : any;
lasku : any;

tiedot = () : void => {
  if(this.lasku == 1) {
    this.lasku = "lasku";
  } else {
    this.lasku = "Käteinen"
  }

let uusiTiedot : any = {
  'nimi' : this.nimi,
  'puh' : this.puh,
  'sposti' : this.sposti,
  'maksu' : this.lasku,
}
this.data.tiedot.push(uusiTiedot);

}

  ngOnInit() {
  }

}
