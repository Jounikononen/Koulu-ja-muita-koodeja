import { HenkilorekisteriService } from './../henkilorekisteri.service';
import { Component, OnInit } from '@angular/core';
import { ActivatedRoute } from '@angular/router';

@Component({
  selector: 'app-henkilo',
  templateUrl: './henkilo.page.html',
  styleUrls: ['./henkilo.page.scss'],
})
export class HenkiloPage implements OnInit {

  henkilo : any;


  constructor(private route : ActivatedRoute, private henkilorekisteri : HenkilorekisteriService) { }

  ngOnInit() {

    let indeksi = Number(this.route.snapshot.paramMap.get("indeksi"));

    this.henkilo = this.henkilorekisteri.henkilot[indeksi];

  }

}
