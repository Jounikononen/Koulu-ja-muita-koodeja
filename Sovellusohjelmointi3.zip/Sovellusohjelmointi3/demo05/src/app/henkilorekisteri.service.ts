import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';

@Injectable({
  providedIn: 'root'
})
export class HenkilorekisteriService {

  henkilot : any[] = null;

  constructor(private http : HttpClient) {
    
    this.http.get("https://uinames.com/api/?amount=30&region=finland&ext").subscribe((data : any[]) => {

      this.henkilot = data;

    });

  }
}
