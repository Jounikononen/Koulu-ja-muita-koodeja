import { Component } from '@angular/core';
import { HttpClient } from '@angular/common/http';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent {

  maara : any;
  muunnos : any;
  tulos : any;
  valittu : string;
  summa : number;
  valuutat : any[];
  vari : string;
  testi : any;
  url : string = "https://api.exchangeratesapi.io/latest";

  
  //Haetaan valuutoista data heti ohjelman käynnistymisen yhteydessä
  constructor(private http : HttpClient) { 
      //Yhdistetään valuuttasivustolle
      this.http.get(this.url).subscribe((data : any) => {
      //Haetaan valuuttojen nimet ja arvot
      this.valuutat = data.rates;
      //Muutetaan objecti JSONiksi jotta vältytään erroreilta ngForissa
      this.testi = Object.keys(this.valuutat).map(key => ({type: key, value: this.valuutat[key]}));

    })
    }

    muunna = () : void => {
      //Muutetaan pilkut pisteiksi
      this.muunnos = this.maara.replace(/[,]/g, ".");
      
      //Tarkastetaan onko syötetty euromäärä kirjaimia/tyhjä
      if (isNaN(this.muunnos) || this.muunnos.length <  1) {
        this.tulos = "Syötä ainoastaan numeroita!";
        this.vari = "alert alert-danger";
      } else if (this.valittu == undefined) {
        this.tulos = "Et valinnut valuuttaa!";
        this.vari = "alert alert-danger";
      } else {
      //Tehdään laskutoimitukset ja muut toimenpiteet
      this.muunnos = this.maara.replace(/[,]/g, ".");
      this.summa = this.valuutat[this.valittu] * this.muunnos;
      this.vari = "alert alert-success";
      this.tulos = "Muunnoksen tulos: " + this.muunnos + " EUR = " + this.summa + " " + this.valittu;
      //Muutetaan tulostuksen pisteet pilkuiksi
      this.tulos  = this.tulos.replace(/[.]/g, ",");
      }
    }

  }

  



