export interface Velka {
    nimi : string;
    maara : number;
  }
  