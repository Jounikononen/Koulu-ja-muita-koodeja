import { Injectable } from '@angular/core';
import { Velka } from './Velka';

@Injectable({
  providedIn: 'root'
})
export class VelkalistaService {


  velat : Velka[] = [];
  length: number;
  


  constructor() { }


  
}

