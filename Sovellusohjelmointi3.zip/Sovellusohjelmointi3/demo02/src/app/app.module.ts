import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { FormsModule } from '@angular/forms';

import { AppComponent } from './app.component';
import { UusiComponent } from './uusi/uusi.component';
import { ListaComponent } from './lista/lista.component';

const reitit : Routes = [{
path : "uusi",
component : UusiComponent
},
{
path : "",
component : ListaComponent
}
];

@NgModule({
  declarations: [
    AppComponent,
    UusiComponent,
    ListaComponent
  ],
  imports: [
    BrowserModule,
    FormsModule,
    RouterModule.forRoot(reitit)
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
