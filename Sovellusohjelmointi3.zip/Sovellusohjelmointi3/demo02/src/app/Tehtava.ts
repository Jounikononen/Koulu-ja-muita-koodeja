export interface Tehtava {
    id : number;
    nimi : string;
    ohje : string;
}