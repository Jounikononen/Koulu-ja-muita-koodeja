const fs = require("fs");

module.exports = {

    "avaa" : (callback) => {

        fs.readFile("./models/data.json", (err, data) => {

            callback(err, JSON.parse(data));

        });

    },

    "tallenna" : (uusidata, callback) => {

        fs.writeFile("./models/data.json", JSON.stringify(uusidata, null, 2), (err) => {

            callback(err);

        });

    }    

}