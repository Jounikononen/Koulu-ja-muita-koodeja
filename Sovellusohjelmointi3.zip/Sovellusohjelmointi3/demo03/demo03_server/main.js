const restify = require("restify");

const server = restify.createServer();

const corsMiddleware = require("restify-cors-middleware");

const cors = corsMiddleware({
                                "origins" : ["http://localhost:*"]
                            });

const tehtavalista = require("./models/tehtavalista");

const portti = 3010;

server.pre(restify.pre.sanitizePath()); // korjataan ylimääräiset kauttaviivat pois
server.pre(cors.preflight); // Tehdään pyyntöjä edeltävät CORS-valmistelut
server.use(restify.plugins.bodyParser()); // Otetaan mukaan bodyParser
server.use(cors.actual); // Kytketään CORS-asetukset/otsikot jokaiseen pyyntöön

server.get("/api/tehtavalista", (req, res, next) => {

    tehtavalista.avaa((err, data) => {

        if (!err) {

            res.send(200, data);

        } else {

            res.send(500, {"virhe" : "Tiedostoa ei voitu aukaista"});

        }


    });
    
    return next();

});

server.put("/api/tehtavalista", (req, res, next) => {

    tehtavalista.tallenna(req.body, (err, data) => {

        if (!err) {

            res.send(200, {"virhe" : "Tiedot tallennettu"});

        } else {

            res.send(500, {"virhe" : "Tiedostoa ei voitu tallentaa."});
        }

    });
    
    return next();

});

server.listen(portti, () => {

    console.log(`Palvelin käynnistyi porttiin ${portti}`);

});

