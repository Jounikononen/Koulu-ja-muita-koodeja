import { Component, OnInit } from '@angular/core';
import { TehtavalistaService } from '../tehtavalista.service';
import { Tehtava } from '../Tehtava';
import { Router } from '@angular/router';

@Component({
  selector: 'app-uusi',
  templateUrl: './uusi.component.html',
  styleUrls: ['./uusi.component.css']
})
export class UusiComponent implements OnInit {

  nimi : string;
  ohje : string;
  constructor(private tehtavalista : TehtavalistaService, private router : Router) { }

  ngOnInit() {
  }


  lisaaUusi = () : void => {
    
  let uusiTehtava : Tehtava = {
                    "id" : this.tehtavalista.tehtavat[this.tehtavalista.tehtavat.length - 1].id + 1,
                    "nimi" : this.nimi,
                    "ohje" : this.ohje
  }

  this.tehtavalista.tehtavat.push(uusiTehtava);

  this.tehtavalista.tallennaTiedot();

  this.router.navigate(["/lista"]);

  }
}
