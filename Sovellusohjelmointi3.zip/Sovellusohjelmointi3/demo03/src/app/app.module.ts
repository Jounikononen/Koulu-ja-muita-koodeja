import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { HttpClientModule } from '@angular/common/http';
import { FormsModule } from '@angular/forms';

import { AppComponent } from './app.component';
import { KoiraComponent } from './koira/koira.component';
import { UusiComponent } from './uusi/uusi.component';
import { ListaComponent } from './lista/lista.component';

const reitit : Routes = [
                          {
                            path : "koira",
                            component : KoiraComponent
                          },
                          {path : "lista/uusi",
                        component : UusiComponent
                      },
                      {
                        path : "lista",
                        component : ListaComponent
                      }
                          
                        ]

@NgModule({
  declarations: [
    AppComponent,
    KoiraComponent,
    ListaComponent,
    UusiComponent
  ],
  imports: [
    BrowserModule,
    FormsModule,
    HttpClientModule,
    RouterModule.forRoot(reitit)
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
